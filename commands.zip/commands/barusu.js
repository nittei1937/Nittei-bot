const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

const BARUSU = require("../data/barusu/barusu.json");
const HANSYA = require("../data/barusu/hansya.json");
const AUTHO = require("../data/barusu/authority.json");
const {
    addSchedule,
    removeSchedule,
    getSchedules,
    formatDiscordTime,
    getExecuteAt
} = require("../utils/schedule");

function createAutocomplete(data) {
    return async interaction => {
        try {
            const focused = interaction.options.getFocused().toLowerCase();
            const choices = Object.entries(data)
                .filter(([id, value]) => id.toLowerCase().includes(focused) || value.name.toLowerCase().includes(focused))
                .slice(0, 25)
                .map(([id, value]) => ({ name: value.name, value: id }));
            await interaction.respond(choices);
        } catch (error) {
            console.error(error);
            if (!interaction.responded) await interaction.respond([]);
        }
    };
}

function getTarget(interaction, optionName = "user") {
    const member = interaction.options.getMember(optionName);
    const user = interaction.options.getUser(optionName);
    return {
        id: user.id,
        name: member?.displayName ?? user.username
    };
}

function createSchedule(interaction, target, message, executeAt) {
    addSchedule({
        channelId: interaction.channelId,
        guildId: interaction.guildId,
        userId: target.id,
        userName: target.name,
        content: `<@${target.id}>${message}`,
        executeAt
    });
}

function getTimeOptions(interaction) {
    const delay = interaction.options.getInteger("delay");
    const hour = interaction.options.getInteger("hour");
    const minute = interaction.options.getInteger("minute");

    if ((hour === null) !== (minute === null)) return null;
    return { delay, hour, minute };
}

function hasPermission(userId, permission) {
    if (!permission) return true;

    if (permission === "admin") {
        return AUTHO.admins.includes(userId);
    }

    if (permission === "owner") {
        return AUTHO.owners.includes(userId);
    }

    // バルス無効化専用の権限（authority.json の nullifiers）
    if (permission === "nullifier") {
        return AUTHO.nullifiers?.includes(userId) ?? false;
    }

    return false;
}

function createExecute(data) {
    return async interaction => {
        const type = interaction.options.getString("type");
        const info = data[type];

        if (!info) {
            return interaction.reply({
                content: "その種類は存在しません。",
                ephemeral: true
            });
        }

        // 権限限定（管理者・オーナー・バルス無効化権限者）
        if (!hasPermission(interaction.user.id, info.permission)) {
            return interaction.reply({
                content: "このコマンドを使用する権限がありません。",
                ephemeral: true
            });
        }

        const target = getTarget(interaction);
        const mode = info.mode ?? "normal";

        if (mode === "physical") {
            const actorName = interaction.member?.displayName
                ?? interaction.user.globalName
                ?? interaction.user.username;
            const embed = new EmbedBuilder()
                .setColor(0x8b0000)
                .setTitle("💪 物理的バルス")
                .setDescription(
            `${target.name}へ物理的バルス！

            ${actorName}も物理的バルス！`
                );

            return interaction.reply({
                embeds: [embed]
            });
        }

        if (mode === "ricochet") {
            const secondUser = interaction.options.getUser("user2");
            if (!secondUser) {
                return interaction.reply({ content: "跳弾式バルスでは「user2」も指定してください。", ephemeral: true });
            }

            const secondTarget = getTarget(interaction, "user2");
            const embed = new EmbedBuilder()
                .setColor(0x00bfff)
                .setTitle("🪞 跳弾式バルス")
                .setDescription(
            `${target.name}と${secondTarget.name}に跳弾式バルス！`
                );

            return interaction.reply({
                embeds: [embed]
            });
        }

        // 時間差式
        if (mode === "delayed") {
            const timeOptions = getTimeOptions(interaction);
            if (!timeOptions) {
                return interaction.reply({
                    content: "時刻指定では「hour」と「minute」を両方入力してください。",
                    ephemeral: true
                });
            }

            const executeAt = getExecuteAt(timeOptions);
            createSchedule(interaction, target, info.message, executeAt);
            const embed = new EmbedBuilder()
                .setColor(0xFF9900)
                .setDescription(
            `${info.name}

            発動予定：${formatDiscordTime(executeAt)}`
                );

            return interaction.reply({
                content: `${target.name}へ`,
                embeds: [embed]
            });
        }

        if (mode === "multi_delayed") {
            const delays = ["delay", "delay2", "delay3"]
                .map(option => interaction.options.getInteger(option))
                .filter(delay => delay !== null);

            if (delays.length === 0) {
                return interaction.reply({
                    content: "多段時間差式バルスでは「delay」を1つ以上入力してください。",
                    ephemeral: true
                });
            }

            const executeAts = delays.map(delay => getExecuteAt({ delay, hour: null, minute: null }));
            for (const executeAt of executeAts) {
                createSchedule(interaction, target, info.message, executeAt);
            }

            const embed = new EmbedBuilder()
                .setColor(0xFFCC00)
                .setDescription(
            `${info.name}

            発動予定
            ${executeAts.map(formatDiscordTime).join("\n")}`
                );

            return interaction.reply({
                content: `${target.name}へ`,
                embeds: [embed]
            });
        }

        // バルス無効化（予約済みの時間差式・多段時間差式バルスを取り消す）
        if (mode === "nullify") {
            const removed = getSchedules().filter(schedule =>
                schedule.guildId === interaction.guildId && schedule.userId === target.id
            );

            for (const schedule of removed) {
                removeSchedule(schedule.id);
            }

            if (removed.length === 0) {
                return interaction.reply({
                    content: `${target.name}への予約バルスは見つかりませんでした。`,
                    ephemeral: true
                });
            }

            const embed = new EmbedBuilder()
                .setColor(0x00ff7f)
                .setTitle("🛡️ バルス無効化")
                .setDescription(`${target.name}への予約バルス（${removed.length}件）を無効化しました。`)
                .setFooter({
                    text: `実行者：${interaction.member?.displayName ?? interaction.user.username}`
                });

            return interaction.reply({ embeds: [embed] });
        }

        // 管理者バルス
        if (info.permission === "admin" && info.permission === "owner") {
            const embed = new EmbedBuilder()
                .setColor(0x8B0000)
                .setDescription(info.name)
                .setFooter({
                    text: `実行者：${interaction.member?.displayName ?? interaction.user.username}`
                });

            return interaction.reply({
                content: `${target.name}へ`,
                embeds: [embed]
            });
        }

        // 通常バルス／反射
        const embed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setDescription(info.name);

        return interaction.reply({
            content: `${target.name}へ`,
            embeds: [embed]
        });
    };
}

const barusuCommand = {
    data: new SlashCommandBuilder()
        .setName("barusu")
        .setDescription("バルス関連コマンド")
        .addSubcommand(sub =>
            sub.setName("barusu")
                .setDescription("バルスを放つ")
                .addStringOption(option => option.setName("type").setDescription("種類").setRequired(true).setAutocomplete(true))
                .addUserOption(option => option.setName("user").setDescription("対象").setRequired(true))
                .addUserOption(option => option.setName("user2").setDescription("跳弾先（跳弾式バルスのみ）"))
                .addIntegerOption(option => option.setName("delay").setDescription("発動までの分数（時間差式・多段時間差式）").setMinValue(1).setMaxValue(525600))
                .addIntegerOption(option => option.setName("delay2").setDescription("2回目までの分数（多段時間差式のみ）").setMinValue(1).setMaxValue(525600))
                .addIntegerOption(option => option.setName("delay3").setDescription("3回目までの分数（多段時間差式のみ）").setMinValue(1).setMaxValue(525600))
                .addIntegerOption(option => option.setName("hour").setDescription("発動時（0〜23、時間差式のみ）").setMinValue(0).setMaxValue(23))
                .addIntegerOption(option => option.setName("minute").setDescription("発動分（0〜59、時間差式のみ）").setMinValue(0).setMaxValue(59))
        )
        .addSubcommand(sub =>
            sub.setName("hansya")
                .setDescription("反射・バルス無効化を放つ")
                .addStringOption(option => option.setName("type").setDescription("種類").setRequired(true).setAutocomplete(true))
                .addUserOption(option => option.setName("user").setDescription("対象").setRequired(true))
        ),
    autocomplete: async interaction => {
        const data = interaction.options.getSubcommand() === "hansya" ? HANSYA : BARUSU;
        return createAutocomplete(data)(interaction);
    },
    execute: async interaction => {
        const data = interaction.options.getSubcommand() === "hansya" ? HANSYA : BARUSU;
        return createExecute(data)(interaction);
    }
};

module.exports = [barusuCommand];
